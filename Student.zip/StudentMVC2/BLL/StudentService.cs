﻿namespace BLL;
using BOL;
using DAL;

public class StudentService
{
    public static List<Student> GetAll()
    {
        List<Student> slist = DBManager.GetAll();
        return slist; 
    }

    public static void Add(int Id, string Name , string Email)
    {
        DBManager.Add( Id,Name ,Email);
    }


    public static void Delete(int Id)
    {
        DBManager.Delete( Id);
    }

     public static void Update(int Id, string Name , string Email)
    {
        DBManager.Update( Id,Name ,Email);
    }
}
