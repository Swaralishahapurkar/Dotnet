﻿namespace BOL;

public class Student
{
    public int Id{get;set;}
    public string  Name{get;set;}
    public string  Email{get;set;}

    public Student(int Id, string Name, string Email)
    {
        this.Id=Id;
        this.Name=Name;
        this.Email=Email;
    }
}
