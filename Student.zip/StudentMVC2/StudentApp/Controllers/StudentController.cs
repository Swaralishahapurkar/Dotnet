using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StudentApp.Models;
using BOL;
using BLL;
namespace StudentApp.Controllers;

public class StudentController : Controller
{
    private readonly ILogger<StudentController> _logger;

    public StudentController(ILogger<StudentController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult List()
    {

        List<Student> slist = StudentService.GetAll();
        ViewData["StudentList"]=slist;
        return View();
    }

    public IActionResult AddStudent()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AddStudent(int Id, string Name , string Email)
    {
        StudentService.Add(Id,Name ,Email);
        return View();
    }

    public IActionResult DeleteStudent()
    {
        return View();
    }

    [HttpPost]
    public IActionResult DeleteStudent(int id)
    {
        StudentService.Delete(id);
        return View();
    }

    public IActionResult UpdateStudent()
    {
         
        return View();
    }

[HttpPost]
    public IActionResult UpdateStudent(int Id, string Name , string Email)
    {
         StudentService.Update( Id,Name ,Email);
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
