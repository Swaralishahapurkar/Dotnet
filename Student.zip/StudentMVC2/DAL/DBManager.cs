﻿namespace DAL;
using BOL;
using MySql.Data.MySqlClient;

public class DBManager
{
    public static List<Student> GetAll()
    {
        List<Student> slist = new List<Student>();

        MySqlConnection conn = new MySqlConnection();

        conn.ConnectionString = @"server=localhost; port=3306;user=root;password=Jagtap@2499;database=iet";

        string query = "select * from Student11";

        MySqlCommand command = new MySqlCommand(query,conn);

        try{
            conn.Open();
            MySqlDataReader reader = command.ExecuteReader();

            while(reader.Read())
            {
                int id = int.Parse(reader["ID"].ToString());
                string name = reader["Name"].ToString();
                string email = reader["Email"].ToString();


                slist.Add(new Student(id,name,email));
                
            }
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }

        return slist;
    }


    public static void Add(int Id, string Name , string Email)
    {

        MySqlConnection conn = new MySqlConnection();

        conn.ConnectionString = @"server=localhost; port=3306;user=root;password=Jagtap@2499;database=iet";

        string query = "insert into student11 values(@ID,@Name,@Email)";

        MySqlCommand command = new MySqlCommand(query,conn);

        command.Parameters.AddWithValue("@ID",Id);
        command.Parameters.AddWithValue("@Name",Name);
        command.Parameters.AddWithValue("@Email",Email);


        try{
            conn.Open();
            command.ExecuteNonQuery();
                
            
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }

    }


    public static void Delete(int Id)
    {

        MySqlConnection conn = new MySqlConnection();

        conn.ConnectionString = @"server=localhost; port=3306;user=root;password=Jagtap@2499;database=iet";

        string query = "delete from student11 where ID="+Id;

        MySqlCommand command = new MySqlCommand(query,conn);

        try{
            conn.Open();
            command.ExecuteNonQuery();
                
            
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }

    }


    public static void Update(int Id, string Name , string Email)
    {

        MySqlConnection conn = new MySqlConnection();

        conn.ConnectionString = @"server=localhost; port=3306;user=root;password=Jagtap@2499;database=iet";

        string query = "update student11 set Name='"+Name+"', Email='"+Email+"' where Id="+Id;

        MySqlCommand command = new MySqlCommand(query,conn);

        try{
            conn.Open();
            command.ExecuteNonQuery();
                
            
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }

    }

}
